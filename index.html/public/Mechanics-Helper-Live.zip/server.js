"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const os = require("os");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const DB_PATH = path.join(DATA_DIR, "db.json");
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const BIO_MAX = 320;

const RIVERSIDE_BIO =
  "Family-run shop since 1998. Brakes, engines, and same-day diagnostics. We text you before we turn a wrench.";
const LEON_BIO =
  "I come to your driveway. Scan tools, common parts, and straight talk. Nights and weekends if the car is down.";

function passHash(s) {
  let h = 2166136261;
  const str = "mh|" + String(s || "");
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

function shopCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function uniqueCode(data) {
  const used = new Set();
  for (const s of data.shops) used.add(s.code);
  for (const u of data.users) if (u.code) used.add(u.code);
  let c = shopCode();
  while (used.has(c)) c = shopCode();
  return c;
}

function slotDays(days, hhmm) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const [h, m] = hhmm.split(":").map(Number);
  d.setHours(h, m, 0, 0);
  return d.toISOString();
}

function seed() {
  const now = Date.now();
  return {
    shops: [
      {
        id: "s-main",
        name: "Riverside Auto",
        code: "RIV4",
        ownerId: "u-shop",
        techs: ["Shop Desk", "Alex Ruiz"],
        bio: RIVERSIDE_BIO,
      },
    ],
    users: [
      {
        id: "u-maya",
        name: "Maya Chen",
        email: "maya@example.com",
        phone: "5550148821",
        role: "customer",
        pass: passHash("demo123"),
      },
      {
        id: "u-shop",
        name: "Shop Desk",
        email: "shop@example.com",
        phone: "5550100000",
        role: "shop",
        shopId: "s-main",
        shopName: "Riverside Auto",
        shopRole: "owner",
        pass: passHash("demo123"),
      },
      {
        id: "u-alex",
        name: "Alex Ruiz",
        email: "alex@example.com",
        phone: "5550100001",
        role: "shop",
        shopId: "s-main",
        shopName: "Riverside Auto",
        shopRole: "tech",
        pass: passHash("demo123"),
      },
      {
        id: "u-indy",
        name: "Leon Miles",
        email: "indy@example.com",
        phone: "5550166000",
        role: "independent",
        businessName: "Leon Mobile Repair",
        serviceMode: "mobile",
        code: "LEON",
        bio: LEON_BIO,
        pass: passHash("demo123"),
      },
    ],
    jobs: [
      {
        id: "MH-4821",
        createdAt: now - 86400000 * 2,
        providerId: "s-main",
        providerType: "shop",
        providerName: "Riverside Auto",
        assignedTo: "Alex Ruiz",
        name: "Maya Chen",
        phone: "5550148821",
        email: "maya@example.com",
        year: "2019",
        make: "Honda",
        model: "CR-V",
        symptoms: "Grinding noise when braking, especially downhill.",
        slot: slotDays(1, "09:00"),
        status: "repair",
        notes: [
          { at: now - 86400000 * 2, text: "Booked online.", by: "system" },
          {
            at: now - 3600000 * 8,
            text: "Front pads at 2mm. Rotors scored. Customer approved pads + rotors.",
            by: "shop",
          },
        ],
      },
      {
        id: "MH-4822",
        createdAt: now - 3600000 * 5,
        providerId: "u-indy",
        providerType: "independent",
        providerName: "Leon Mobile Repair",
        assignedTo: "Leon Miles",
        name: "James Ortiz",
        phone: "5550193304",
        email: "james@example.com",
        year: "2016",
        make: "Ford",
        model: "F-150",
        symptoms: "Check engine light. Rough idle after warmup.",
        slot: slotDays(0, "11:30"),
        status: "diagnosing",
        notes: [
          { at: now - 3600000 * 5, text: "Booked online.", by: "system" },
          { at: now - 3600000, text: "Pulled codes P0302. Checking coil pack and injector.", by: "shop" },
        ],
      },
      {
        id: "MH-4820",
        createdAt: now - 86400000,
        providerId: "s-main",
        providerType: "shop",
        providerName: "Riverside Auto",
        assignedTo: "Shop Desk",
        name: "Priya Shah",
        phone: "5550167742",
        email: "priya@example.com",
        year: "2022",
        make: "Toyota",
        model: "Camry",
        symptoms: "Oil change and 30k service.",
        slot: slotDays(0, "08:00"),
        status: "ready",
        notes: [
          { at: now - 86400000, text: "Booked online.", by: "system" },
          { at: now - 3600000 * 2, text: "Service complete. Cabin filter replaced.", by: "shop" },
        ],
      },
    ],
    sessions: {},
  };
}

function load() {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(DB_PATH)) {
      const data = seed();
      save(data);
      return data;
    }
    const data = JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
    if (!data.shops) data.shops = [];
    if (!data.users) data.users = [];
    if (!data.jobs) data.jobs = [];
    if (!data.sessions) data.sessions = {};
    return data;
  } catch (err) {
    console.error("Could not read data/db.json, reseeding.", err.message);
    const data = seed();
    save(data);
    return data;
  }
}

function save(data) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function publicUser(u) {
  if (!u) return null;
  const { pass, ...rest } = u;
  return rest;
}

function listProviders(data) {
  const shops = data.shops.map((s) => ({
    id: s.id,
    type: "shop",
    name: s.name,
    detail: "Repair shop",
    code: s.code,
    bio: s.bio || "",
  }));
  const indy = data.users
    .filter((u) => u.role === "independent")
    .map((u) => ({
      id: u.id,
      type: "independent",
      name: u.businessName || u.name,
      detail:
        u.serviceMode === "mobile"
          ? "Mobile mechanic"
          : u.serviceMode === "shop"
            ? "Independent shop"
            : "Mobile or drop-off",
      code: u.code || "",
      bio: u.bio || "",
    }));
  return shops.concat(indy);
}

function findUser(data, emailOrPhone) {
  const q = String(emailOrPhone || "").trim().toLowerCase();
  const digits = q.replace(/\D/g, "");
  return (
    data.users.find((u) => {
      if ((u.email || "").toLowerCase() === q) return true;
      const ph = (u.phone || "").replace(/\D/g, "");
      return digits.length >= 4 && ph === digits;
    }) || null
  );
}

function userJobs(data, user) {
  if (!user) return data.jobs;
  if (user.role === "shop") return data.jobs.filter((j) => j.providerId === user.shopId);
  if (user.role === "independent") return data.jobs.filter((j) => j.providerId === user.id);
  return data.jobs.filter((j) => j.email === user.email || j.phone === user.phone || j.userId === user.id);
}

function authUser(req, data) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return null;
  const uid = data.sessions[token];
  if (!uid) return null;
  return data.users.find((u) => u.id === uid) || null;
}

function send(res, status, body, extra) {
  const json = typeof body === "string" ? body : JSON.stringify(body);
  const headers = {
    "Content-Type": extra && extra.type ? extra.type : "application/json; charset=utf-8",
    "Cache-Control": extra && extra.cache ? extra.cache : "no-store",
  };
  res.writeHead(status, headers);
  res.end(json);
}

function notFound(res) {
  send(res, 404, { error: "Not found" });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > 1e6) {
        reject(new Error("Too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
};

function serveStatic(req, res) {
  let urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
  if (urlPath === "/") urlPath = "/index.html";
  const file = path.normalize(path.join(PUBLIC, urlPath));
  if (!file.startsWith(PUBLIC)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.readFile(file, (err, buf) => {
    if (err) {
      if (urlPath !== "/index.html") {
        const index = path.join(PUBLIC, "index.html");
        return fs.readFile(index, (e2, html) => {
          if (e2) {
            res.writeHead(404);
            return res.end("Not found");
          }
          res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
          res.end(html);
        });
      }
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": ext === ".html" || ext === ".js" ? "no-store" : "public, max-age=86400",
    });
    res.end(buf);
  });
}

async function handleApi(req, res, url) {
  const data = load();
  const method = req.method || "GET";
  const pathname = url.pathname;
  const user = authUser(req, data);

  if (method === "POST" && pathname === "/api/login") {
    const body = await readBody(req);
    const found = findUser(data, body.id || body.email || body.phone);
    if (!found || found.pass !== passHash(body.password || body.pw || "")) {
      return send(res, 401, { error: "Email/phone or password is wrong." });
    }
    const token = crypto.randomBytes(24).toString("hex");
    data.sessions[token] = found.id;
    save(data);
    return send(res, 200, { token, user: publicUser(found) });
  }

  if (method === "POST" && pathname === "/api/register") {
    const body = await readBody(req);
    const emailL = String(body.email || "").trim().toLowerCase();
    const phoneD = String(body.phone || "").replace(/\D/g, "");
    const name = String(body.name || "").trim();
    const password = String(body.password || body.pw || "");
    if (!name || !password || (!emailL && !phoneD)) {
      return send(res, 400, { error: "Name, password, and email or phone are required." });
    }
    if (password.length < 6) return send(res, 400, { error: "Password must be at least 6 characters." });
    if (findUser(data, emailL || phoneD)) {
      return send(res, 400, { error: "That email or phone already has an account." });
    }
    const role = body.role === "shop" || body.role === "independent" ? body.role : "customer";
    const nu = {
      id: "u-" + crypto.randomBytes(3).toString("hex"),
      name,
      email: emailL,
      phone: phoneD,
      role,
      pass: passHash(password),
    };
    if (role === "shop") {
      if (body.shopJoin === "join") {
        const code = String(body.shopCode || "").trim().toUpperCase();
        const shop = data.shops.find((s) => s.code === code);
        if (!shop) return send(res, 400, { error: "No shop with that code." });
        nu.shopId = shop.id;
        nu.shopName = shop.name;
        nu.shopRole = "tech";
        if (!shop.techs.includes(nu.name)) shop.techs.push(nu.name);
      } else {
        const shopName = String(body.shopName || "").trim() || nu.name + "'s Shop";
        const shop = {
          id: "s-" + crypto.randomBytes(3).toString("hex"),
          name: shopName,
          code: uniqueCode(data),
          ownerId: nu.id,
          techs: [nu.name],
          bio: "",
        };
        data.shops.push(shop);
        nu.shopId = shop.id;
        nu.shopName = shop.name;
        nu.shopRole = "owner";
      }
    }
    if (role === "independent") {
      nu.businessName = String(body.businessName || "").trim() || nu.name;
      nu.serviceMode = body.serviceMode || "both";
      nu.code = uniqueCode(data);
      nu.bio = "";
    }
    data.users.push(nu);
    const token = crypto.randomBytes(24).toString("hex");
    data.sessions[token] = nu.id;
    save(data);
    return send(res, 200, { token, user: publicUser(nu) });
  }

  if (method === "POST" && pathname === "/api/logout") {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (token && data.sessions[token]) {
      delete data.sessions[token];
      save(data);
    }
    return send(res, 200, { ok: true });
  }

  if (method === "GET" && pathname === "/api/me") {
    if (!user) return send(res, 401, { error: "Please log in." });
    return send(res, 200, { user: publicUser(user) });
  }

  if (method === "GET" && pathname === "/api/providers") {
    return send(res, 200, { providers: listProviders(data) });
  }

  if (method === "GET" && pathname === "/api/find") {
    const code = String(url.searchParams.get("code") || "").trim().toUpperCase();
    const p = listProviders(data).find((x) => x.code === code) || null;
    if (!p) return send(res, 404, { error: "No shop or mechanic with that code." });
    return send(res, 200, { provider: p });
  }

  if (method === "GET" && pathname === "/api/jobs") {
    if (!user) return send(res, 401, { error: "Please log in." });
    let jobs = userJobs(data, user);
    const q = String(url.searchParams.get("q") || "").trim().toUpperCase();
    if (q) {
      const digits = q.replace(/\D/g, "");
      jobs = jobs.filter((j) => {
        if (j.id.toUpperCase() === q) return true;
        const ph = (j.phone || "").replace(/\D/g, "");
        return digits.length >= 4 && (ph.endsWith(digits) || ph.includes(digits));
      });
    }
    return send(res, 200, { jobs });
  }

  if (method === "POST" && pathname === "/api/jobs") {
    if (!user) return send(res, 401, { error: "Please log in." });
    const body = await readBody(req);
    const providers = listProviders(data);
    const provider = providers.find((p) => p.id === body.providerId && p.type === body.providerType);
    if (!provider) return send(res, 400, { error: "Choose a shop or mechanic" });
    if (!body.year || !body.make || !body.model || !body.symptoms || !body.slot) {
      return send(res, 400, { error: "Fill in all fields" });
    }
    const job = {
      id: "MH-" + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      createdAt: Date.now(),
      name: String(body.name || user.name),
      phone: String(body.phone || user.phone || "").replace(/\D/g, ""),
      email: String(body.email || user.email || ""),
      year: String(body.year),
      make: String(body.make),
      model: String(body.model),
      symptoms: String(body.symptoms),
      slot: new Date(body.slot).toISOString(),
      status: "scheduled",
      providerId: provider.id,
      providerType: provider.type,
      providerName: provider.name,
      assignedTo: "",
      notes: [{ at: Date.now(), text: "Booked from customer app.", by: "system" }],
    };
    data.jobs.unshift(job);
    save(data);
    return send(res, 200, { job });
  }

  const jobMatch = pathname.match(/^\/api\/jobs\/([^/]+)(\/note)?$/);
  if (jobMatch && user) {
    const id = decodeURIComponent(jobMatch[1]);
    const job = data.jobs.find((j) => j.id === id);
    if (!job) return send(res, 404, { error: "Job not found." });
    const isOwner =
      user.role === "shop"
        ? job.providerId === user.shopId
        : user.role === "independent"
          ? job.providerId === user.id
          : job.userId === user.id || job.email === user.email || job.phone === user.phone;
    if (!isOwner) return send(res, 403, { error: "Not your job." });

    if (method === "GET" && !jobMatch[2]) return send(res, 200, { job });

    if (method === "PATCH" && !jobMatch[2]) {
      if (user.role === "customer") return send(res, 403, { error: "Customers can't update status." });
      const body = await readBody(req);
      if (body.status) job.status = body.status;
      if (body.assignedTo !== undefined) job.assignedTo = body.assignedTo;
      save(data);
      return send(res, 200, { job });
    }

    if (method === "POST" && jobMatch[2]) {
      if (user.role === "customer") return send(res, 403, { error: "Customers can't post shop notes." });
      const body = await readBody(req);
      const text = String(body.text || "").trim();
      if (!text) return send(res, 400, { error: "Note is empty." });
      job.notes = job.notes || [];
      job.notes.push({ at: Date.now(), text, by: "shop" });
      save(data);
      return send(res, 200, { job });
    }
  }

  if (method === "POST" && pathname === "/api/profile") {
    if (!user) return send(res, 401, { error: "Please log in." });
    const body = await readBody(req);
    if (user.role === "shop") {
      if (user.shopRole !== "owner") return send(res, 403, { error: "Only the shop owner can edit this." });
      const shop = data.shops.find((s) => s.id === user.shopId);
      if (!shop) return send(res, 404, { error: "Shop not found." });
      if (body.name) {
        const name = String(body.name).trim();
        if (!name) return send(res, 400, { error: "Shop name is required." });
        shop.name = name;
        for (const u of data.users) if (u.shopId === shop.id) u.shopName = name;
      }
      if (body.bio !== undefined) shop.bio = String(body.bio).trim().slice(0, BIO_MAX);
      save(data);
      return send(res, 200, { user: publicUser(data.users.find((u) => u.id === user.id)), shop });
    }
    if (user.role === "independent") {
      const u = data.users.find((x) => x.id === user.id);
      if (body.businessName) {
        const name = String(body.businessName).trim();
        if (!name) return send(res, 400, { error: "Business name is required." });
        u.businessName = name;
      }
      if (body.bio !== undefined) u.bio = String(body.bio).trim().slice(0, BIO_MAX);
      if (body.serviceMode) u.serviceMode = body.serviceMode;
      save(data);
      return send(res, 200, { user: publicUser(u) });
    }
    return send(res, 400, { error: "No public profile to edit." });
  }

  if (method === "POST" && pathname === "/api/code/rotate") {
    if (!user) return send(res, 401, { error: "Please log in." });
    const next = uniqueCode(data);
    if (user.role === "shop") {
      if (user.shopRole !== "owner") return send(res, 403, { error: "Only the owner can rotate the code." });
      const shop = data.shops.find((s) => s.id === user.shopId);
      if (!shop) return send(res, 404, { error: "Shop not found." });
      shop.code = next;
      save(data);
      return send(res, 200, { code: next });
    }
    if (user.role === "independent") {
      const u = data.users.find((x) => x.id === user.id);
      u.code = next;
      save(data);
      return send(res, 200, { code: next, user: publicUser(u) });
    }
    return send(res, 400, { error: "No code to rotate." });
  }

  if (method === "POST" && pathname === "/api/shop/techs") {
    if (!user || user.role !== "shop" || user.shopRole !== "owner") {
      return send(res, 403, { error: "Only the shop owner can add technicians." });
    }
    const body = await readBody(req);
    const shop = data.shops.find((s) => s.id === user.shopId);
    const name = String(body.name || "").trim();
    if (!shop || !name) return send(res, 400, { error: "Name required." });
    if (!shop.techs.includes(name)) shop.techs.push(name);
    save(data);
    return send(res, 200, { shop });
  }

  if (method === "GET" && pathname === "/api/shop") {
    if (!user || user.role !== "shop") return send(res, 403, { error: "Not a shop account." });
    const shop = data.shops.find((s) => s.id === user.shopId) || null;
    return send(res, 200, { shop });
  }

  return notFound(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", "http://localhost");
    if (url.pathname.startsWith("/api/")) {
      await handleApi(req, res, url);
      return;
    }
    serveStatic(req, res);
  } catch (err) {
    console.error(err);
    if (!res.headersSent) send(res, 500, { error: err.message || "Server error" });
  }
});

function lanAddress() {
  const nets = os.networkInterfaces();
  for (const list of Object.values(nets)) {
    for (const n of list || []) {
      if (n.family === "IPv4" && !n.internal) return n.address;
    }
  }
  return null;
}

server.listen(PORT, HOST, () => {
  const lan = lanAddress();
  console.log("");
  console.log("  Mechanics Helper is running.");
  console.log("  Keep this window open.");
  console.log("");
  console.log("  On this computer:   http://localhost:" + PORT);
  if (lan) console.log("  On your phone (same Wi-Fi): http://" + lan + ":" + PORT);
  console.log("");
  console.log("  Demo: maya@ / shop@ / indy@ example.com   password demo123");
  console.log("  Find codes: RIV4  and  LEON");
  console.log("");
});
