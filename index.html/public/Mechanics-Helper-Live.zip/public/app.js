/* Mechanics Helper — shop, independent, customer */
const VEHICLE_DATA = {
  Acura: ["CL", "CSX", "ILX", "Integra", "Legend", "MDX", "NSX", "RDX", "RL", "RLX", "RSX", "TL", "TLX", "TSX", "ZDX", "Other"],
  "Alfa Romeo": ["4C", "Giulia", "Stelvio", "Tonale", "Other"],
  Audi: ["A3", "A4", "A5", "A6", "A7", "A8", "e-tron", "e-tron GT", "Q3", "Q4 e-tron", "Q5", "Q7", "Q8", "R8", "RS3", "RS5", "RS6", "RS7", "S3", "S4", "S5", "S6", "S8", "SQ5", "SQ7", "SQ8", "TT", "Other"],
  BMW: ["1 Series", "2 Series", "3 Series", "4 Series", "5 Series", "6 Series", "7 Series", "8 Series", "i3", "i4", "i5", "i7", "iX", "M2", "M3", "M4", "M5", "X1", "X2", "X3", "X4", "X5", "X6", "X7", "XM", "Z3", "Z4", "Other"],
  Buick: ["Cascada", "Century", "Enclave", "Encore", "Encore GX", "Envision", "Envista", "LaCrosse", "LeSabre", "Lucerne", "Park Avenue", "Rainier", "Regal", "Rendezvous", "Terraza", "Verano", "Other"],
  Cadillac: ["ATS", "CT4", "CT5", "CT6", "CTS", "DTS", "DeVille", "Eldorado", "Escalade", "Escalade ESV", "Escalade EXT", "Lyriq", "SRX", "STS", "XT4", "XT5", "XT6", "XTS", "Other"],
  Chevrolet: ["Astro", "Avalanche", "Aveo", "Blazer", "Blazer EV", "Bolt EUV", "Bolt EV", "Camaro", "Caprice", "Captiva", "Cavalier", "City Express", "Cobalt", "Colorado", "Corvette", "Cruze", "Equinox", "Express", "HHR", "Impala", "Malibu", "Monte Carlo", "S-10", "Silverado 1500", "Silverado 2500HD", "Silverado 3500HD", "Sonic", "Spark", "SS", "SSR", "Suburban", "Tahoe", "Trailblazer", "Traverse", "Trax", "Uplander", "Venture", "Volt", "Other"],
  Chrysler: ["200", "300", "Aspen", "Concorde", "Crossfire", "Pacifica", "PT Cruiser", "Sebring", "Town & Country", "Voyager", "Other"],
  Dodge: ["Avenger", "Caliber", "Caravan", "Challenger", "Charger", "Dakota", "Dart", "Durango", "Grand Caravan", "Hornet", "Journey", "Magnum", "Neon", "Nitro", "Ram 1500", "Ram 2500", "Stratus", "Viper", "Other"],
  Fiat: ["124 Spider", "500", "500L", "500X", "Other"],
  Ford: ["Bronco", "Bronco Sport", "C-Max", "Contour", "Crown Victoria", "E-Series", "E-Transit", "EcoSport", "Edge", "Escape", "Escort", "Excursion", "Expedition", "Explorer", "Explorer Sport Trac", "F-150", "F-250", "F-350", "Fiesta", "Five Hundred", "Flex", "Focus", "Freestar", "Freestyle", "Fusion", "Maverick", "Mustang", "Mustang Mach-E", "Probe", "Ranger", "Taurus", "Thunderbird", "Transit", "Transit Connect", "Windstar", "Other"],
  Genesis: ["Electrified GV70", "G70", "G80", "G90", "GV60", "GV70", "GV80", "Other"],
  GMC: ["Acadia", "Canyon", "Envoy", "Hummer EV", "Jimmy", "Safari", "Savana", "Sierra 1500", "Sierra 2500HD", "Sierra 3500HD", "Sonoma", "Terrain", "Yukon", "Yukon XL", "Other"],
  Honda: ["Accord", "Accord Hybrid", "Civic", "Civic Hatchback", "Civic Si", "Civic Type R", "Clarity", "CR-V", "CR-V Hybrid", "CR-Z", "Crosstour", "Element", "Fit", "HR-V", "Insight", "Odyssey", "Passport", "Pilot", "Prelude", "Prologue", "Ridgeline", "S2000", "Other"],
  Hyundai: ["Accent", "Azera", "Elantra", "Elantra GT", "Elantra Hybrid", "Elantra N", "Entourage", "Equus", "Genesis", "Genesis Coupe", "Ioniq", "Ioniq 5", "Ioniq 6", "Kona", "Kona Electric", "Palisade", "Santa Cruz", "Santa Fe", "Sonata", "Tucson", "Tucson Hybrid", "Veloster", "Venue", "Veracruz", "XG350", "Other"],
  Infiniti: ["EX35", "FX35", "FX45", "FX50", "G25", "G35", "G37", "I35", "JX35", "M35", "M37", "M45", "Q50", "Q60", "Q70", "QX30", "QX50", "QX55", "QX60", "QX70", "QX80", "Other"],
  Jaguar: ["E-PACE", "F-PACE", "F-TYPE", "I-PACE", "S-Type", "XE", "XF", "XJ", "XK", "X-Type", "Other"],
  Jeep: ["Cherokee", "Commander", "Compass", "Gladiator", "Grand Cherokee", "Grand Cherokee L", "Grand Wagoneer", "Liberty", "Patriot", "Renegade", "Wagoneer", "Wrangler", "Wrangler 4xe", "Other"],
  Kia: ["Borrego", "Cadenza", "Carnival", "EV6", "EV9", "Forte", "K4", "K5", "K900", "Niro", "Niro EV", "Optima", "Rio", "Rondo", "Sedona", "Seltos", "Sorento", "Soul", "Soul EV", "Spectra", "Sportage", "Stinger", "Telluride", "Other"],
  "Land Rover": ["Defender", "Discovery", "Discovery Sport", "Freelander", "LR2", "LR3", "LR4", "Range Rover", "Range Rover Evoque", "Range Rover Sport", "Range Rover Velar", "Other"],
  Lexus: ["CT", "ES", "GS", "GX", "HS", "IS", "LC", "LFA", "LS", "LX", "NX", "RC", "RX", "RZ", "SC", "TX", "UX", "Other"],
  Lincoln: ["Aviator", "Continental", "Corsair", "LS", "Mark LT", "MKC", "MKS", "MKT", "MKX", "MKZ", "Nautilus", "Navigator", "Town Car", "Zephyr", "Other"],
  Mazda: ["CX-3", "CX-30", "CX-5", "CX-50", "CX-7", "CX-9", "CX-90", "Mazda2", "Mazda3", "Mazda5", "Mazda6", "MX-5 Miata", "MX-30", "Protege", "RX-8", "Tribute", "Other"],
  "Mercedes-Benz": ["A-Class", "B-Class", "C-Class", "CL-Class", "CLA", "CLK", "CLS", "E-Class", "EQB", "EQE", "EQS", "G-Class", "GL-Class", "GLA", "GLB", "GLC", "GLE", "GLK", "GLS", "M-Class", "Metris", "S-Class", "SL", "SLC", "SLK", "Sprinter", "Other"],
  Mini: ["Clubman", "Convertible", "Cooper", "Countryman", "Hardtop", "Paceman", "Other"],
  Mitsubishi: ["Eclipse", "Eclipse Cross", "Endeavor", "Galant", "Lancer", "Mirage", "Montero", "Outlander", "Outlander Sport", "Outlander PHEV", "Other"],
  Nissan: ["350Z", "370Z", "Altima", "Armada", "cube", "Frontier", "GT-R", "Juke", "Kicks", "Leaf", "Maxima", "Murano", "NV200", "Pathfinder", "Quest", "Rogue", "Rogue Sport", "Sentra", "Titan", "Titan XD", "Versa", "Versa Note", "Xterra", "Z", "Other"],
  Pontiac: ["Aztek", "Bonneville", "Firebird", "G5", "G6", "G8", "Grand Am", "Grand Prix", "GTO", "Solstice", "Sunfire", "Torrent", "Vibe", "Other"],
  Porsche: ["718 Boxster", "718 Cayman", "911", "Cayenne", "Macan", "Panamera", "Taycan", "Other"],
  Ram: ["1500", "2500", "3500", "ProMaster", "ProMaster City", "Other"],
  Rivian: ["R1S", "R1T", "Other"],
  Saturn: ["Astra", "Aura", "Ion", "L-Series", "Outlook", "Relay", "Sky", "Vue", "Other"],
  Subaru: ["Ascent", "Baja", "BRZ", "Crosstrek", "Forester", "Impreza", "Legacy", "Outback", "Solterra", "SVX", "Tribeca", "WRX", "WRX STI", "XV Crosstrek", "Other"],
  Tesla: ["Cybertruck", "Model 3", "Model S", "Model X", "Model Y", "Other"],
  Toyota: ["4Runner", "86", "Avalon", "bZ4X", "C-HR", "Camry", "Camry Hybrid", "Celica", "Corolla", "Corolla Cross", "Corolla Hatchback", "Corolla Hybrid", "Crown", "FJ Cruiser", "GR86", "GR Corolla", "GR Supra", "Highlander", "Highlander Hybrid", "Land Cruiser", "Matrix", "Mirai", "Prius", "Prius C", "Prius Prime", "Prius V", "RAV4", "RAV4 Hybrid", "RAV4 Prime", "Sequoia", "Sienna", "Solara", "Supra", "Tacoma", "Tundra", "Venza", "Yaris", "Yaris iA", "Other"],
  Volkswagen: ["Arteon", "Atlas", "Atlas Cross Sport", "Beetle", "CC", "e-Golf", "Eos", "Golf", "Golf GTI", "Golf R", "ID.4", "ID. Buzz", "Jetta", "Passat", "Phaeton", "Routan", "Taos", "Tiguan", "Touareg", "Other"],
  Volvo: ["C30", "C40", "C70", "S40", "S60", "S80", "S90", "V50", "V60", "V90", "XC40", "XC60", "XC70", "XC90", "Other"],
};
const YEARS = [];
(function () {
  const now = new Date().getFullYear() + 1;
  for (let y = now; y >= 1990; y--) YEARS.push(String(y));
})();
const BIO_MAX = 320;
const STATUSES = [
  { id: "scheduled", label: "Scheduled", customer: "Appointment booked", badge: "scheduled" },
  { id: "enroute", label: "On the way", customer: "Mechanic is heading to you", badge: "enroute" },
  { id: "checkedin", label: "Checked in", customer: "Vehicle is with the mechanic", badge: "checkedin" },
  { id: "diagnosing", label: "Diagnosing", customer: "Technician is inspecting the vehicle", badge: "diagnosing" },
  { id: "parts", label: "Waiting on parts", customer: "Parts ordered — we'll update when they arrive", badge: "parts" },
  { id: "repair", label: "In repair", customer: "Work is underway", badge: "repair" },
  { id: "ready", label: "Ready for pickup", customer: "Your vehicle is ready", badge: "ready" },
  { id: "done", label: "Completed", customer: "Picked up — thank you", badge: "done" },
];

function vehicleKind(j) {
  const blob = `${j.make || ""} ${j.model || ""}`.toLowerCase();
  if (/f-150|f-250|f-350|silverado|sierra|ram |tacoma|tundra|ranger|frontier|gladiator|ridgeline|canyon|colorado|maverick|titan|santa cruz|avalanche|cybertruck|r1t|1500|2500|3500/.test(blob)) return "truck";
  if (/odyssey|pacifica|sienna|carnival|sedona|town & country|voyager|caravan|quest|uplander|venture|freestar|windstar|transit|promaster|express|savana|metris|sprinter/.test(blob)) return "van";
  if (/mustang|camaro|challenger|corvette|supra|370z|350z|gt-r|911|718|miata|mx-5|brz|gr86|s2000|nsx|viper|stinger|civic si|civic type r|elantra n|charger/.test(blob)) return "sports";
  if (/suv|crossover|rav4|cr-v|hr-v|pilot|passport|highlander|4runner|tahoe|suburban|yukon|expedition|explorer|escape|edge|bronco|equinox|traverse|wrangler|cherokee|telluride|sorento|tucson|santa fe|palisade|outback|forester|ascent|crosstrek|cx-5|mdx|rx |x5|q5|model y|model x|escalade|navigator|macan|cayenne|range rover/.test(blob)) return "suv";
  return "sedan";
}
function carImage(j) { return "/img/car-" + vehicleKind(j) + ".jpg"; }
function statusMeta(id) { return STATUSES.find((s) => s.id === id) || STATUSES[0]; }
function fmtWhen(iso) {
  return new Date(iso).toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}
function fmtShort(iso) {
  return new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}
function vehicleLabel(j) { return `${j.year} ${j.make} ${j.model}`; }
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    if (c === "&") return "&" + "amp;";
    if (c === "<") return "&" + "lt;";
    if (c === ">") return "&" + "gt;";
    if (c === '"') return "&" + "quot;";
    return "&#39;";
  });
}
function slots() {
  const out = [];
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  for (let d = 1; d <= 7; d++) {
    for (const t of ["08:00", "09:30", "11:00", "13:00", "14:30", "16:00"]) {
      const [h, m] = t.split(":").map(Number);
      const dt = new Date(start);
      dt.setDate(dt.getDate() + d);
      dt.setHours(h, m, 0, 0);
      if (dt.getDay() === 0) continue;
      out.push(dt);
    }
  }
  return out;
}
function has(t, words) { return words.some((w) => t.includes(w)); }
function block(urgency, lead, bullets, chips) {
  const tag = urgency === "urgent" ? "Urgency: don't keep driving it if you can avoid it." : urgency === "soon" ? "Urgency: book this week, sooner if it's changing fast." : "Urgency: a normal appointment is fine unless something new shows up.";
  return { text: [lead, "", ...bullets.map((b) => "• " + b), "", tag].join("\n"), chips, urgency };
}
function greet() {
  return { text: "I'm the shop helper. Tell me the year, make, and model if you have them, then what's going on — a noise, a light, a smell, a leak, or how it drives.\n\nI can narrow likely causes. If the car isn't safe to drive, say so.", chips: ["Check engine light", "Won't start", "Brake noise", "Overheating", "Shaking", "Leak under the car"] };
}
function diagReply(text) {
  const t = (text || "").toLowerCase();
  if (has(t, ["overheat", "steam", "coolant", "running hot"])) return block("urgent", "Overheating is one of the fastest ways to wreck an engine.", ["If the gauge is high or you see steam: pull over and shut it down.", "Common causes: low coolant, thermostat, water pump, fan, head gasket.", "Book a cooling-system check."], ["Book cooling-system check"]);
  if (has(t, ["won't start", "wont start", "no start", "click", "dead battery"])) return block("soon", "A no-start is very bookable — we don't need you to guess the part.", ["Clicks usually mean a weak battery or a bad connection.", "If it cranks but never catches, think fuel, spark, or a sensor."], ["Book no-start diagnosis"]);
  if (has(t, ["check engine", "engine light"])) return block("soon", "A check-engine light is a stored fault code — a clue, not a parts list.", ["We scan it first. Same light can be a gas cap or a misfire.", "A flashing light is an active misfire — don't ignore it."], ["Book a scan + diagnosis"]);
  if (has(t, ["brake", "grinding", "squeak", "squeal", "pedal"])) return block("soon", "Brake noise can be cheap wear indicators or pads that are gone.", ["Tell us which end, and whether it happens cold or after a drive.", "A soft or sinking pedal is urgent — hydraulic problem."], ["Book brake inspection"]);
  if (has(t, ["shake", "vibration", "wobble"])) return block("soon", "Vibration is usually tires, a bent wheel, or rotors if it happens while braking.", ["Note the mph when it starts and whether the steering wheel shakes."], ["Book vibration diagnosis"]);
  if (has(t, ["leak", "puddle", "dripping"])) return block("soon", "A drip is easier to find when it's still wet.", ["Sweet green/orange is often coolant. Thick brown/black is oil.", "Park on cardboard overnight if you can."], ["Book leak inspection"]);
  if (t.length < 12) return { text: "Give me a bit more. For example: “2018 Civic, grinds when I brake going downhill.”", chips: ["Check engine light", "Won't start", "Brake noise"] };
  return block("normal", "I have enough to start a ticket, even if the cause isn't obvious yet.", ["A good visit starts with what you feel/hear/smell and when it started.", "I can drop this description into a booking."], ["Book this diagnosis"]);
}

const I = {
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>',
  house: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  clip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></svg>',
  qr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/></svg>',
  user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/></svg>',
  msg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22z"/></svg>',
  cal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/></svg>',
  pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>',
};

const App = {
  view: "welcome",
  user: null,
  token: localStorage.getItem("mh.token") || "",
  toast: "",
  locked: null,
  codeInput: "",
  selectedId: null,
  draft: null,
  jobs: [],
  providers: [],
  shop: null,
  filter: "active",
  messages: [],
  make: "",
  pick: "",
  pendingSymptoms: "",
  role: "customer",
  join: "create",

  homeFor(role) { return role === "shop" || role === "independent" ? "shopHome" : "home"; },
  isProvider() { return this.user && (this.user.role === "shop" || this.user.role === "independent"); },
  shareCode() {
    if (!this.user) return "";
    if (this.user.role === "shop") return (this.shop && this.shop.code) || "";
    if (this.user.role === "independent") return this.user.code || "";
    return "";
  },
  flash(msg) {
    this.toast = msg;
    this.render();
    setTimeout(() => { this.toast = ""; this.render(); }, 2200);
  },
  go(view) { this.view = view; this.render(); },

  async api(path, opts) {
    const headers = { "Content-Type": "application/json" };
    if (this.token) headers.Authorization = "Bearer " + this.token;
    const res = await fetch(path, Object.assign({ headers }, opts || {}));
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || "Request failed");
    return body;
  },

  async boot() {
    const q = new URLSearchParams(location.search).get("ref") || "";
    const fromUrl = q.trim().toUpperCase();
    if (fromUrl) localStorage.setItem("mh.ref", fromUrl);
    const code = fromUrl || localStorage.getItem("mh.ref") || "";
    try {
      const p = await this.api("/api/providers");
      this.providers = p.providers || [];
    } catch { this.providers = []; }
    if (code) {
      const found = this.providers.find((x) => x.code === code);
      if (found) this.locked = found;
    }
    if (this.token) {
      try {
        const me = await this.api("/api/me");
        this.user = me.user;
        await this.refresh();
        this.view = this.user.role === "customer" && this.locked ? "book" : this.homeFor(this.user.role);
      } catch {
        this.token = "";
        localStorage.removeItem("mh.token");
      }
    }
    this.render();
  },

  async refresh() {
    if (!this.user) return;
    try {
      const j = await this.api("/api/jobs");
      this.jobs = j.jobs || [];
    } catch { this.jobs = []; }
    if (this.user.role === "shop") {
      try {
        const s = await this.api("/api/shop");
        this.shop = s.shop;
      } catch { this.shop = null; }
    }
    try {
      const p = await this.api("/api/providers");
      this.providers = p.providers || [];
      if (this.locked) {
        this.locked = this.providers.find((x) => x.code === this.locked.code) || this.locked;
      }
    } catch { /* keep */ }
  },

  async applyCode(raw, goBook) {
    const code = String(raw || "").trim().toUpperCase();
    try {
      const r = await this.api("/api/find?code=" + encodeURIComponent(code));
      this.locked = r.provider;
      localStorage.setItem("mh.ref", r.provider.code);
      this.flash("Found " + r.provider.name);
      if (goBook && this.user && this.user.role === "customer") this.view = "book";
    } catch (e) {
      this.flash(e.message);
    }
    this.render();
  },
  clearLock() {
    this.locked = null;
    this.codeInput = "";
    localStorage.removeItem("mh.ref");
    this.flash("Pick any shop or mechanic");
    this.render();
  },

  async login(ev) {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    try {
      const r = await this.api("/api/login", { method: "POST", body: JSON.stringify({ id: fd.get("id"), password: fd.get("pw") }) });
      this.token = r.token;
      this.user = r.user;
      localStorage.setItem("mh.token", r.token);
      await this.refresh();
      this.view = this.user.role === "customer" && this.locked ? "book" : this.homeFor(this.user.role);
      this.flash("Hi " + this.user.name.split(" ")[0]);
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async register(ev) {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    try {
      const r = await this.api("/api/register", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("name"),
          email: fd.get("email"),
          phone: fd.get("phone"),
          password: fd.get("pw"),
          role: this.role,
          shopJoin: this.join,
          shopName: fd.get("shopName") || "",
          shopCode: fd.get("shopCode") || "",
          businessName: fd.get("biz") || "",
          serviceMode: fd.get("mode") || "both",
        }),
      });
      this.token = r.token;
      this.user = r.user;
      localStorage.setItem("mh.token", r.token);
      await this.refresh();
      this.view = this.homeFor(this.user.role);
      this.flash("Hi " + this.user.name.split(" ")[0]);
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async logout() {
    try { await this.api("/api/logout", { method: "POST", body: "{}" }); } catch { /* ok */ }
    this.token = "";
    this.user = null;
    this.shop = null;
    localStorage.removeItem("mh.token");
    this.view = "welcome";
    this.render();
  },

  async book(ev) {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    const raw = this.locked ? this.locked.type + ":" + this.locked.id : String(fd.get("provider") || this.pick || "");
    const [ptype, pid] = raw.split(":");
    try {
      const r = await this.api("/api/jobs", {
        method: "POST",
        body: JSON.stringify({
          providerId: pid,
          providerType: ptype,
          name: fd.get("name"),
          phone: fd.get("phone"),
          email: fd.get("email"),
          year: fd.get("year"),
          make: fd.get("make"),
          model: fd.get("model"),
          symptoms: fd.get("symptoms"),
          slot: fd.get("slot"),
        }),
      });
      this.draft = r.job;
      this.pendingSymptoms = "";
      this.view = "confirm";
      await this.refresh();
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async setStatus(id, status) {
    try {
      await this.api("/api/jobs/" + encodeURIComponent(id), { method: "PATCH", body: JSON.stringify({ status }) });
      await this.api("/api/jobs/" + encodeURIComponent(id) + "/note", { method: "POST", body: JSON.stringify({ text: "Status set to " + statusMeta(status).label }) });
      await this.refresh();
      this.flash("Status updated");
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async assign(id, name) {
    try {
      await this.api("/api/jobs/" + encodeURIComponent(id), { method: "PATCH", body: JSON.stringify({ assignedTo: name }) });
      await this.refresh();
      this.flash("Assigned");
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async note(ev, id) {
    ev.preventDefault();
    const text = String(new FormData(ev.target).get("note") || "").trim();
    if (!text) return;
    try {
      await this.api("/api/jobs/" + encodeURIComponent(id) + "/note", { method: "POST", body: JSON.stringify({ text }) });
      ev.target.reset();
      await this.refresh();
      this.flash("Update sent to customer");
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async saveShop(ev) {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    try {
      const r = await this.api("/api/profile", { method: "POST", body: JSON.stringify({ name: fd.get("shopName"), bio: fd.get("bio") }) });
      this.user = r.user;
      this.shop = r.shop;
      this.flash("Shop profile saved");
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async saveIndy(ev) {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    try {
      const r = await this.api("/api/profile", { method: "POST", body: JSON.stringify({ businessName: fd.get("biz"), bio: fd.get("bio"), serviceMode: fd.get("mode") }) });
      this.user = r.user;
      this.flash("Profile saved");
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async addTech(ev) {
    ev.preventDefault();
    const name = String(new FormData(ev.target).get("tech") || "").trim();
    try {
      const r = await this.api("/api/shop/techs", { method: "POST", body: JSON.stringify({ name }) });
      this.shop = r.shop;
      ev.target.reset();
      this.flash("Technician added");
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  async rotate() {
    try {
      const r = await this.api("/api/code/rotate", { method: "POST", body: "{}" });
      if (r.user) this.user = r.user;
      if (this.shop) this.shop.code = r.code;
      this.flash("New code: " + r.code);
      await this.refresh();
    } catch (e) { this.flash(e.message); }
    this.render();
  },
  copy(text, label) {
    navigator.clipboard.writeText(text).then(() => this.flash(label || "Copied")).catch(() => this.flash(text));
  },

  jobById(id) { return this.jobs.find((j) => j.id === id); },
  logo() { return '<div class="brand"><img src="/img/logo.jpg" alt=""><div><div class="name">Mechanics Helper</div><div class="sub">Shop · Independent · Customer</div></div></div>'; },
  top(title, back) {
    return `<div class="back"><button type="button" onclick="App.go('${back}')" aria-label="Back">${I.back}</button><h2>${esc(title)}</h2></div>`;
  },
  field(label, inner) { return `<label class="field"><span>${esc(label)}</span>${inner}</label>`; },
  jobCard(j, shop) {
    const st = statusMeta(j.status);
    return `<button type="button" class="job" onclick="App.openJob('${esc(j.id)}', ${shop ? "true" : "false"})">
      <div class="row2"><img src="${carImage(j)}" alt="">
        <div class="grow"><div class="kind">${esc(vehicleKind(j))}</div>
        <h3>${esc(shop ? j.name : vehicleLabel(j))}</h3>
        <div class="sub">${esc(shop ? vehicleLabel(j) : j.name)} · ${esc(j.id)}${j.assignedTo ? " · " + esc(j.assignedTo) : ""}${!shop && j.providerName ? " · " + esc(j.providerName) : ""}</div>
        <span class="badge badge-${st.badge}">${esc(shop ? st.label : st.customer)}</span></div></div></button>`;
  },
  openJob(id, shop) {
    this.selectedId = id;
    this.view = shop ? "shopJob" : "job";
    this.render();
  },
  sendChat(text) {
    const res = diagReply(text);
    this.messages.push({ role: "user", text }, { role: "bot", text: res.text, chips: res.chips });
    this.render();
  },
  chatSubmit(ev) {
    ev.preventDefault();
    const v = String(new FormData(ev.target).get("chat") || "").trim();
    if (!v) return;
    this.sendChat(v);
  },
  chip(c) {
    if (/book/i.test(c)) {
      this.pendingSymptoms = this.messages.filter((m) => m.role === "user").map((m) => m.text).join(" — ") || c;
      this.view = "book";
      this.render();
      return;
    }
    this.sendChat(c);
  },

  renderWelcome() {
    const l = this.locked;
    return `${this.logo()}
      ${l ? `<div class="card accent mb"><p class="eyebrow gold">You were referred</p><h2>${esc(l.name)}</h2><p class="muted">${esc(l.detail)} · code ${esc(l.code)}</p>${l.bio ? `<p class="mt2">${esc(l.bio)}</p>` : ""}<p class="muted mt2">Log in as a customer to book this mechanic.</p></div>`
        : `<div class="hero-card mb"><h1 class="hero">Sign in to book<br>or run the bay.</h1><p class="muted mt2">Customers track repairs. Shops and independents share a find code so people land on the right bay.</p></div>`}
      <div class="card mb"><p class="eyebrow">Have a shop or mechanic code?</p>
        <div class="row mt2"><input class="inp" placeholder="RIV4 or LEON" value="${esc(this.codeInput)}" oninput="App.codeInput=this.value.toUpperCase();this.value=App.codeInput" onkeydown="if(event.key==='Enter')App.applyCode(App.codeInput,false)">
        <button class="btn primary shrink" onclick="App.applyCode(App.codeInput,false)">Find</button></div></div>
      <div class="stack"><button class="btn primary" onclick="App.go('login')">Log in</button>
      <button class="btn ghost" onclick="App.go('register')">Create an account</button></div>
      <div class="card mt muted"><p style="font-weight:600;color:var(--fg)">Demo logins · password demo123</p>
        <p class="mt2">Customer: maya@example.com</p><p>Shop: shop@example.com</p><p>Independent: indy@example.com</p>
        <p class="mt2">Find codes: RIV4 · LEON</p></div>`;
  },
  renderLogin() {
    return `<form class="stack" onsubmit="App.login(event)">${this.top("Log in", "welcome")}
      ${this.field("Email or phone", '<input class="inp" name="id" autocomplete="username" required>')}
      ${this.field("Password", '<input class="inp" name="pw" type="password" autocomplete="current-password" required>')}
      <button class="btn primary" type="submit">Log in</button>
      <button class="btn ghost" type="button" onclick="App.go('register')">Need an account?</button></form>`;
  },
  renderRegister() {
    const r = this.role;
    return `<form class="stack" onsubmit="App.register(event)">${this.top("Create account", "welcome")}
      ${this.field("Full name", '<input class="inp" name="name" required>')}
      ${this.field("Email", '<input class="inp" name="email" type="email">')}
      ${this.field("Phone", '<input class="inp" name="phone" inputmode="tel">')}
      ${this.field("Password", '<input class="inp" name="pw" type="password" required>')}
      <p class="eyebrow">I am</p>
      <div class="seg">${["customer", "shop", "independent"].map((x) => `<button type="button" class="${r === x ? "on" : ""}" onclick="App.role='${x}';App.render()">${x === "independent" ? "Independent" : x === "shop" ? "Shop" : "Customer"}</button>`).join("")}</div>
      ${r === "shop" ? `<div class="seg"><button type="button" class="${this.join === "create" ? "on" : ""}" onclick="App.join='create';App.render()">Create shop</button><button type="button" class="${this.join === "join" ? "on" : ""}" onclick="App.join='join';App.render()">Join shop</button></div>
        ${this.join === "create" ? this.field("Shop name", '<input class="inp" name="shopName" placeholder="Riverside Auto">') : this.field("Shop team code", '<input class="inp" name="shopCode" placeholder="RIV4">')}` : ""}
      ${r === "independent" ? `${this.field("Business name", '<input class="inp" name="biz" placeholder="Leon Mobile Repair">')}
        ${this.field("How you work", '<select class="inp" name="mode"><option value="mobile">I go to the customer</option><option value="shop">They come to me</option><option value="both">Both</option></select>')}` : ""}
      <button class="btn primary" type="submit">Create account</button></form>`;
  },
  renderHome() {
    const u = this.user;
    const l = this.locked;
    return `<div class="brand"><img src="/img/logo.jpg" alt=""><div class="grow"><div class="name">Mechanics Helper</div><div class="sub">${esc(u.name)}</div></div>
      <button class="btn ghost sm" onclick="App.go('account')">Account</button></div>
      ${l ? `<div class="card accent mb"><p class="eyebrow gold">Booking with</p><h2>${esc(l.name)}</h2><p class="muted">${esc(l.detail)} · ${esc(l.code)}</p>${l.bio ? `<p class="mt2">${esc(l.bio)}</p>` : ""}<button class="btn link mt2" onclick="App.clearLock()">Choose a different shop</button></div>`
        : `<div class="hero-card mb"><h1 class="hero">Get the car in. Stay in the loop.</h1><p class="muted mt2">Ask the helper, book a bay, and watch progress instead of calling the desk.</p></div>`}
      <div class="card mb"><p class="eyebrow">Have a shop or mechanic code?</p>
        <div class="row mt2"><input class="inp" placeholder="RIV4 or LEON" value="${esc(this.codeInput)}" oninput="App.codeInput=this.value.toUpperCase();this.value=App.codeInput" onkeydown="if(event.key==='Enter')App.applyCode(App.codeInput,true)">
        <button class="btn primary shrink" onclick="App.applyCode(App.codeInput,true)">Find</button></div></div>
      <div class="stack"><button class="btn primary" onclick="App.messages=[{role:'bot',text:greet().text,chips:greet().chips}];App.go('diagnose')">Ask the helper</button>
      <button class="btn ghost" onclick="App.go('book')">Book an appointment</button>
      <button class="btn ghost" onclick="App.go('track')">Track a repair</button></div>`;
  },
  renderBook() {
    const u = this.user;
    const l = this.locked;
    const models = this.make ? VEHICLE_DATA[this.make] || [] : [];
    const picked = l || this.providers.find((p) => p.type + ":" + p.id === this.pick);
    return `<form class="stack" onsubmit="App.book(event)">${this.top("New appointment", "home")}
      ${l ? `<div class="card accent">Booking <strong>${esc(l.name)}</strong> · ${esc(l.code)}${l.bio ? `<p class="muted mt2">${esc(l.bio)}</p>` : ""}<button type="button" class="btn link mt2" onclick="App.clearLock()">Choose someone else</button></div>`
        : `${this.field("Who should get this job?", `<select class="inp" name="provider" required onchange="App.pick=this.value;App.render()"><option value="">Choose a shop or mechanic</option>${this.providers.map((p) => `<option value="${p.type}:${p.id}" ${this.pick === p.type + ":" + p.id ? "selected" : ""}>${esc(p.name)} · ${esc(p.code)}</option>`).join("")}</select>`)}
           ${picked && picked.bio ? `<p class="muted">${esc(picked.bio)}</p>` : ""}`}
      ${this.field("Your name", `<input class="inp" name="name" value="${esc(u.name)}" required>`)}
      <div class="grid2">${this.field("Phone", `<input class="inp" name="phone" value="${esc(u.phone || "")}" required>`)}
      ${this.field("Email", `<input class="inp" name="email" type="email" value="${esc(u.email || "")}">`)}</div>
      <div class="grid2">${this.field("Year", `<select class="inp" name="year" required><option value="">Year</option>${YEARS.map((y) => `<option>${y}</option>`).join("")}</select>`)}
      ${this.field("Make", `<select class="inp" name="make" required onchange="App.make=this.value;App.render()"><option value="">Make</option>${Object.keys(VEHICLE_DATA).map((m) => `<option ${this.make === m ? "selected" : ""}>${esc(m)}</option>`).join("")}</select>`)}</div>
      ${this.field("Model", `<select class="inp" name="model" required><option value="">${this.make ? "Select model" : "Select make first"}</option>${models.map((m) => `<option>${esc(m)}</option>`).join("")}</select>`)}
      ${this.field("What’s going on?", `<textarea class="inp" name="symptoms" required>${esc(this.pendingSymptoms)}</textarea>`)}
      ${this.field("Preferred time", `<select class="inp" name="slot" required><option value="">Choose a slot</option>${slots().map((d) => `<option value="${d.toISOString()}">${esc(fmtWhen(d.toISOString()))}</option>`).join("")}</select>`)}
      <button class="btn primary" type="submit">Request appointment</button></form>`;
  },
  renderConfirm() {
    const j = this.draft;
    if (!j) return this.renderHome();
    return `${this.top("You’re on the board", "home")}
      <div class="card" style="text-align:center"><p class="muted">Job code</p><p class="mono-lg" style="font-size:24px;letter-spacing:.18em;color:var(--fg)">${esc(j.id)}</p><p class="muted mt2">Going to ${esc(j.providerName)}</p></div>
      <div class="cover mt"><img class="wide" src="${carImage(j)}" alt=""><div class="pad"><h3>${esc(vehicleLabel(j))}</h3><p class="muted">${esc(fmtWhen(j.slot))}</p></div></div>
      <button class="btn primary full mt" onclick="App.selectedId='${esc(j.id)}';App.go('track')">Track this job</button>`;
  },
  renderTrack() {
    const list = this.jobs;
    return `${this.top("Track a repair", "home")}
      <input class="inp" placeholder="Job code or phone" oninput="App.searchJobs(this.value)">
      <div class="stack mt">${list.length ? list.map((j) => this.jobCard(j, false)).join("") : '<p class="empty">No jobs matched. Try MH-4821.</p>'}</div>`;
  },
  async searchJobs(q) {
    try {
      const r = await this.api("/api/jobs" + (q ? "?q=" + encodeURIComponent(q) : ""));
      this.jobs = r.jobs || [];
    } catch { /* keep */ }
    this.render();
  },
  renderJob(shop) {
    const job = this.jobById(this.selectedId);
    if (!job) return '<p class="muted">Job not found.</p>';
    const st = statusMeta(job.status);
    const idx = STATUSES.findIndex((s) => s.id === job.status);
    const back = shop ? "shopHome" : "track";
    return `${this.top(job.id, back)}
      <div class="cover"><img class="wide" src="${carImage(job)}" alt=""><div class="pad">
        <p class="kind">${esc(vehicleKind(job))}</p><h2>${esc(vehicleLabel(job))}</h2>
        <p class="muted">${esc(job.name)} · ${esc(job.providerName)}</p>
        <span class="badge badge-${st.badge}">${esc(shop ? st.label : st.customer)}</span>
        <p class="note mt">${esc(job.symptoms)}</p></div></div>
      <h2 class="mt mb">Progress</h2>
      ${STATUSES.map((s, i) => `<div class="progress"><div class="dot ${i <= idx ? "on" : ""}"></div><div><div style="font-size:14px;font-weight:600">${esc(shop ? s.label : s.customer)}</div>${i === idx ? `<div class="dim">Current · ${esc(fmtShort((job.notes.slice(-1)[0] && job.notes.slice(-1)[0].at) || job.createdAt))}</div>` : ""}</div></div>`).join("")}
      ${shop && this.user.role === "shop" && this.shop ? this.field("Assign technician", `<select class="inp" onchange="App.assign('${esc(job.id)}', this.value)"><option value="">Unassigned</option>${(this.shop.techs || []).map((n) => `<option ${job.assignedTo === n ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>`) : ""}
      ${shop ? `<p class="eyebrow mt">Move status</p><div class="stack mt2">${STATUSES.map((s) => `<button type="button" class="status-btn ${job.status === s.id ? "on" : ""}" onclick="App.setStatus('${esc(job.id)}','${s.id}')">${esc(s.label)}</button>`).join("")}</div>
        <form class="mt" onsubmit="App.note(event,'${esc(job.id)}')">${this.field("Customer-facing update", '<textarea class="inp" name="note" placeholder="Pads and rotors installed."></textarea>')}
        <button class="btn primary full mt2" type="submit">Post update</button></form>` : ""}
      <h2 class="mt mb">Updates</h2>
      ${[...job.notes].reverse().map((n) => `<div class="note"><strong style="color:var(--fg)">${n.by === "shop" ? "Shop update" : "System"}</strong> · ${esc(fmtShort(n.at))}<br>${esc(n.text)}</div>`).join("")}`;
  },
  renderShopHome() {
    const u = this.user;
    const title = u.role === "independent" ? u.businessName || "Independent" : u.shopName || "Shop";
    const bio = u.role === "independent" ? u.bio || "" : (this.shop && this.shop.bio) || "";
    const jobs = this.jobs.slice().sort((a, b) => +new Date(a.slot) - +new Date(b.slot));
    const active = jobs.filter((j) => j.status !== "done");
    const ready = jobs.filter((j) => j.status === "ready").length;
    const busy = jobs.filter((j) => ["enroute", "checkedin", "diagnosing", "parts", "repair"].includes(j.status)).length;
    const list = this.filter === "ready" ? jobs.filter((j) => j.status === "ready") : this.filter === "all" ? jobs : active;
    const code = this.shareCode();
    return `<div class="brand"><img src="/img/logo.jpg" alt=""><div><div class="name">${esc(title)}</div><div class="sub">${u.role === "independent" ? "Your jobs" : esc(u.name)}</div></div></div>
      ${bio ? `<p class="muted mb">${esc(bio)}</p>` : ""}
      <div class="card mb"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <div><p class="eyebrow">Customer find code</p><p class="mono-lg" style="text-align:left;font-size:24px">${esc(code || "—")}</p></div>
        <button class="btn primary sm shrink" onclick="App.go('share')">QR & share</button></div>
        <p class="dim mt2">Give this to customers so they book you, not a random shop.</p></div>
      <div class="grid3 mb">
        <div class="card stat"><b>${active.length}</b><div class="dim">Open</div></div>
        <div class="card stat"><b>${busy}</b><div class="dim">${u.role === "independent" ? "Active" : "In bay"}</div></div>
        <div class="card stat"><b>${ready}</b><div class="dim">Ready</div></div></div>
      <div class="seg mb">${["active", "ready", "all"].map((f) => `<button type="button" class="${this.filter === f ? "on" : ""}" onclick="App.filter='${f}';App.render()">${f === "active" ? "Open" : f[0].toUpperCase() + f.slice(1)}</button>`).join("")}</div>
      <div class="stack">${list.map((j) => this.jobCard(j, true)).join("") || '<p class="empty">No jobs in this filter.</p>'}</div>`;
  },
  renderShare() {
    const u = this.user;
    const code = this.shareCode();
    const title = u.role === "independent" ? u.businessName || u.name : u.shopName || "Your shop";
    const link = location.origin + "/?ref=" + encodeURIComponent(code);
    const qr = "https://api.qrserver.com/v1/create-qr-code/?size=280x280&color=0c1220&bgcolor=fff7ed&data=" + encodeURIComponent(link);
    const canRotate = u.role === "independent" || u.shopRole === "owner";
    return `${this.top("Share with customers", "shopHome")}
      <div class="card"><p class="eyebrow">Customer find code</p><h2 class="mt2">${esc(title)}</h2>
      <p class="muted mt2">Print this, text it, or stick it on the counter. Customers type the code or scan the QR and land on you — not a random shop.</p>
      <div class="card mt" style="background:var(--bg2);border:0"><div class="mono-lg">${esc(code)}</div></div>
      <div class="qr-wrap"><img src="${qr}" alt="QR code for ${esc(code)}"></div>
      <div class="grid2"><button class="btn primary sm" type="button" onclick="App.copy('${esc(code)}','Copied code')">Copy code</button>
      <button class="btn ghost sm" type="button" onclick="App.copy('${esc(link)}','Copied link')">Copy link</button></div>
      ${canRotate ? `<button class="btn ghost full mt2" type="button" onclick="App.rotate()">Generate a new code</button>
        <p class="dim mt2">${u.role === "shop" ? "A new code also replaces the employee join code. Old printed QRs stop working." : "Old printed QRs stop working after you generate a new code."}</p>` : ""}
      <p class="dim mt2">Scanning opens this app with you already selected. Demo codes: RIV4 and LEON.</p></div>`;
  },
  renderDiagnose() {
    if (!this.messages.length) this.messages = [{ role: "bot", text: greet().text, chips: greet().chips }];
    return `${this.top("Shop helper", "home")}<div class="chat">
      ${this.messages.map((m) => `<div class="bubble ${m.role === "user" ? "me" : "bot"}">${m.role === "bot" ? '<div class="dim" style="margin-bottom:4px;font-weight:600">Helper</div>' : ""}${esc(m.text)}
        ${m.chips ? `<div class="chips">${m.chips.map((c) => `<button type="button" class="chip" onclick="App.chip(${JSON.stringify(c)})">${esc(c)}</button>`).join("")}</div>` : ""}</div>`).join("")}
      </div>
      <form class="row mt" onsubmit="App.chatSubmit(event)"><input class="inp" name="chat" placeholder="2018 Civic, grinds when braking…"><button class="btn primary shrink" type="submit">Send</button></form>`;
  },
  renderAccount() {
    const u = this.user;
    const shop = this.shop;
    const canEdit = u.role === "shop" && u.shopRole === "owner" && shop;
    const label = u.role === "shop" ? (u.shopRole === "owner" ? "Shop owner" : "Shop technician") : u.role === "independent" ? "Independent mechanic" : "Customer";
    return `${this.top("Account", this.homeFor(u.role))}
      <div class="card"><h2>${esc(u.name)}</h2><p class="muted">${esc(u.email || "No email")}<br>${esc(u.phone || "No phone")}</p><span class="pill">${esc(label)}</span></div>
      ${shop ? `<form class="card mt stack" onsubmit="App.saveShop(event)"><p class="eyebrow">Public shop profile</p>
        ${canEdit ? this.field("Shop name", `<input class="inp" name="shopName" value="${esc(shop.name)}" required>`) : `<h2>${esc(shop.name)}</h2>`}
        ${this.field("Bio — what customers see", canEdit ? `<textarea class="inp" name="bio" maxlength="${BIO_MAX}">${esc(shop.bio || "")}</textarea><p class="count">${(shop.bio || "").length}/${BIO_MAX}</p>` : `<p class="muted">${esc(shop.bio || "The owner hasn’t written a bio yet.")}</p>`)}
        ${canEdit ? '<button class="btn primary" type="submit">Save shop profile</button>' : ""}
        <p class="muted">Team join code — employees use this when they create an account</p>
        <div class="mono-lg" style="font-size:24px;color:var(--fg)">${esc(shop.code)}</div>
        <p class="muted">Team: ${esc((shop.techs || []).join(", "))}</p>
        <p class="dim">Customers use the same code (or the QR on Share) to find this shop.</p></form>
        ${canEdit ? `<form class="row mt" onsubmit="App.addTech(event)"><input class="inp" name="tech" placeholder="Add technician name"><button class="btn ghost shrink" type="submit">Add</button></form>` : ""}` : ""}
      ${u.role === "independent" ? `<form class="card mt stack" onsubmit="App.saveIndy(event)"><p class="eyebrow">Public mechanic profile</p>
        ${this.field("Business name", `<input class="inp" name="biz" value="${esc(u.businessName || u.name)}" required>`)}
        ${this.field("How you work", `<select class="inp" name="mode"><option value="mobile" ${u.serviceMode === "mobile" ? "selected" : ""}>I go to the customer</option><option value="shop" ${u.serviceMode === "shop" ? "selected" : ""}>They come to me</option><option value="both" ${u.serviceMode === "both" || !u.serviceMode ? "selected" : ""}>Both</option></select>`)}
        ${this.field("Bio — what customers see", `<textarea class="inp" name="bio" maxlength="${BIO_MAX}">${esc(u.bio || "")}</textarea>`)}
        <button class="btn primary" type="submit">Save profile</button>
        <p class="dim">Your customer QR is on the Share tab.</p></form>` : ""}
      <button class="btn ghost full mt" onclick="App.logout()">Log out</button>`;
  },
  nav() {
    if (!this.user || ["welcome", "login", "register"].includes(this.view)) return "";
    if (this.isProvider()) {
      return `<nav class="nav n3">
        <button class="${this.view === "shopHome" || this.view === "shopJob" ? "on" : ""}" onclick="App.go('shopHome')">${I.clip}Jobs</button>
        <button class="${this.view === "share" ? "on" : ""}" onclick="App.go('share')">${I.qr}Share</button>
        <button class="${this.view === "account" ? "on" : ""}" onclick="App.go('account')">${I.user}Account</button></nav>`;
    }
    return `<nav class="nav n4">
      <button class="${this.view === "home" ? "on" : ""}" onclick="App.go('home')">${I.house}Home</button>
      <button class="${this.view === "diagnose" ? "on" : ""}" onclick="App.messages=App.messages.length?App.messages:[{role:'bot',text:greet().text,chips:greet().chips}];App.go('diagnose')">${I.msg}Diagnose</button>
      <button class="${this.view === "book" || this.view === "confirm" ? "on" : ""}" onclick="App.go('book')">${I.cal}Book</button>
      <button class="${this.view === "track" || this.view === "job" ? "on" : ""}" onclick="App.go('track')">${I.pin}My car</button></nav>`;
  },
  render() {
    const map = {
      welcome: () => this.renderWelcome(),
      login: () => this.renderLogin(),
      register: () => this.renderRegister(),
      home: () => this.renderHome(),
      book: () => this.renderBook(),
      confirm: () => this.renderConfirm(),
      track: () => this.renderTrack(),
      job: () => this.renderJob(false),
      diagnose: () => this.renderDiagnose(),
      shopHome: () => this.renderShopHome(),
      shopJob: () => this.renderJob(true),
      share: () => this.renderShare(),
      account: () => this.renderAccount(),
    };
    const code = this.isProvider() ? this.shareCode() : (this.locked && this.locked.code) || "Bay";
    const el = document.getElementById("app");
    el.innerHTML = `<div class="shell">
      <header class="topbar"><span>Mechanics Helper</span><span class="mono">${esc(code)}</span></header>
      <main class="${["welcome", "login", "register"].includes(this.view) ? "auth" : ""}">${(map[this.view] || map.welcome)()}</main>
      ${this.nav()}
      ${this.toast ? `<div class="toast">${esc(this.toast)}</div>` : ""}
    </div>`;
  },
};

window.App = App;
App.boot();
