# Mechanics Helper

Open **START-HERE.txt** first.

Start command:

```
node server.js
```

You must run that from the folder that contains `server.js`. Demo logins (password `demo123`): maya@example.com, shop@example.com, indy@example.com. Find codes: **RIV4**, **LEON**.
